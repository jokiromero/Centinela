from datetime import datetime

from app.datos_persistentes import Lectura


l = Lectura()

print(l)
if l is None:
    print("Is None")

if l:
    print("if l")

if not l:
    print("if not l")

if l.total is None:
    print("l.total is None")
    print(f"{l.fecha=}")

if not l.objetivo:
    print(f"not l.objetivo {l.objetivo}")

if not l.total:
    print(f"not l.total  {l.total}")

l = Lectura()
l.fecha=datetime(2025,11,10, 22, 34, 00)
l.dias = 12
l.objetivo = 16400
l.total = 23748.34

print(l)
if not l.objetivo:
    print(f"not l.objetivo {l.objetivo}")

if not l.total:
    print(f"not l.total  {l.total}")

